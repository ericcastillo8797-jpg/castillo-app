/* castillo-equiv.js — equivalencias/sustituciones de alimentos.
   Regla (validada por Alex): cambiar SOLO dentro de la misma familia; igualar por CALORÍAS;
   3-4 opciones; verduras/frutas/salsas NO se sustituyen. El cliente ve gramos + kcal; los
   macros se calculan por detrás. Valores por 100 g (kcal, P, C, G) de la tabla validada. */
(function (w) {
  var ALT = {
    carbo: [
      { n: 'Arroz blanco', en: 'White rice', k: 130, p: 3, c: 28, g: 0 }, { n: 'Pasta', en: 'Pasta', k: 158, p: 6, c: 31, g: 1 },
      { n: 'Pan blanco', en: 'White bread', k: 265, p: 8, c: 51, g: 3 }, { n: 'Patata', en: 'Potato', k: 77, p: 2, c: 17, g: 0 },
      { n: 'Boniato', en: 'Sweet potato', k: 86, p: 2, c: 20, g: 0 }, { n: 'Avena', en: 'Oats', k: 380, p: 14, c: 60, g: 7 },
      { n: 'Cuscús', en: 'Couscous', k: 112, p: 4, c: 23, g: 0 }, { n: 'Garbanzos', en: 'Chickpeas', k: 164, p: 9, c: 27, g: 3 },
      { n: 'Lentejas', en: 'Lentils', k: 116, p: 8, c: 19, g: 0 }
    ],
    prote: [
      { n: 'Pechuga de pollo', en: 'Chicken breast', k: 120, p: 23, c: 0, g: 3 }, { n: 'Pavo', en: 'Turkey', k: 104, p: 17, c: 4, g: 2 },
      { n: 'Ternera magra', en: 'Lean beef', k: 159, p: 28, c: 0, g: 5 }, { n: 'Salmón', en: 'Salmon', k: 146, p: 22, c: 0, g: 6 },
      { n: 'Merluza', en: 'Hake', k: 80, p: 18, c: 0, g: 1 }, { n: 'Atún al natural', en: 'Tuna', k: 100, p: 23, c: 0, g: 1 },
      { n: 'Claras de huevo', en: 'Egg whites', k: 52, p: 11, c: 0.7, g: 0.2 }, { n: 'Gambas', en: 'Prawns', k: 105, p: 20, c: 1, g: 2 }
    ],
    grasa: [
      { n: 'Aceite de oliva', en: 'Olive oil', k: 884, p: 0, c: 0, g: 100 }, { n: 'Aguacate', en: 'Avocado', k: 160, p: 2, c: 9, g: 15 },
      { n: 'Nueces', en: 'Walnuts', k: 654, p: 15, c: 14, g: 65 }, { n: 'Almendras', en: 'Almonds', k: 583, p: 22, c: 20, g: 51 },
      { n: 'Crema de cacahuete', en: 'Peanut butter', k: 588, p: 25, c: 20, g: 50 }
    ],
    lacteo: [
      { n: 'Leche desnatada', en: 'Skim milk', k: 34, p: 3, c: 5, g: 0 }, { n: 'Yogur natural', en: 'Natural yogurt', k: 60, p: 4, c: 5, g: 3 },
      { n: 'Yogur griego', en: 'Greek yogurt', k: 117, p: 4, c: 5, g: 9 }, { n: 'Kéfir', en: 'Kefir', k: 40, p: 3, c: 5, g: 1 },
      // Alex (30 ago): los lacteos se quedaban cortos y el yogur griego solo podia cambiarse
      // por medio litro de kefir. Estos cuatro llevan proteina de verdad, que es lo que faltaba.
      { n: 'Queso batido 0%', en: 'Skimmed quark 0%', k: 47, p: 8, c: 4, g: 0.2 },
      { n: 'Requesón', en: 'Cottage cheese', k: 96, p: 11, c: 3, g: 4 },
      { n: 'Queso fresco 12%', en: 'Fresh cheese 12%', k: 174, p: 12, c: 4, g: 12 },
      { n: 'Skyr', en: 'Skyr', k: 63, p: 11, c: 4, g: 0.2 }
    ],
    // Alex (30 ago): la fruta, la verdura y las salsas TAMBIÉN se cambian, siempre igualando
    // calorías, como todo lo demás. Valores por 100 g validados por él.
    fruta: [
      { n: 'Sandía', en: 'Watermelon', k: 30, p: 0.6, c: 7.6, g: 0.2 }, { n: 'Fresas', en: 'Strawberries', k: 32, p: 0.7, c: 7.7, g: 0.3 },
      { n: 'Melón', en: 'Melon', k: 34, p: 0.8, c: 8.2, g: 0.2 }, { n: 'Papaya', en: 'Papaya', k: 43, p: 0.5, c: 11, g: 0.3 },
      { n: 'Frutos rojos', en: 'Mixed berries', k: 45, p: 0.8, c: 10, g: 0.4 }, { n: 'Naranja', en: 'Orange', k: 47, p: 0.9, c: 12, g: 0.1 },
      { n: 'Piña', en: 'Pineapple', k: 50, p: 0.5, c: 13, g: 0.1 }, { n: 'Manzana', en: 'Apple', k: 52, p: 0.3, c: 14, g: 0.2 },
      { n: 'Mandarina', en: 'Tangerine', k: 53, p: 0.8, c: 13, g: 0.3 }, { n: 'Arándanos', en: 'Blueberries', k: 57, p: 0.7, c: 14, g: 0.3 },
      { n: 'Pera', en: 'Pear', k: 57, p: 0.4, c: 15, g: 0.1 }, { n: 'Mango', en: 'Mango', k: 60, p: 0.8, c: 15, g: 0.4 },
      { n: 'Kiwi', en: 'Kiwi', k: 61, p: 1.1, c: 15, g: 0.5 }, { n: 'Uvas', en: 'Grapes', k: 69, p: 0.7, c: 18, g: 0.2 },
      { n: 'Plátano', en: 'Banana', k: 89, p: 1.1, c: 23, g: 0.3 }
    ],
    verdura: [
      { n: 'Pepino', en: 'Cucumber', k: 15, p: 0.7, c: 3.6, g: 0.1 }, { n: 'Lechuga', en: 'Lettuce', k: 15, p: 1.4, c: 2.9, g: 0.2 },
      { n: 'Calabacín', en: 'Courgette', k: 17, p: 1.2, c: 3.1, g: 0.3 }, { n: 'Tomate', en: 'Tomato', k: 18, p: 0.9, c: 3.9, g: 0.2 },
      { n: 'Tomates cherry', en: 'Cherry tomatoes', k: 18, p: 0.9, c: 3.9, g: 0.2 }, { n: 'Ensalada mixta', en: 'Mixed salad', k: 20, p: 1.3, c: 3.5, g: 0.3 },
      { n: 'Espárragos', en: 'Asparagus', k: 20, p: 2.2, c: 3.9, g: 0.1 }, { n: 'Champiñones', en: 'Mushrooms', k: 22, p: 3.1, c: 3.3, g: 0.3 },
      { n: 'Espinacas', en: 'Spinach', k: 23, p: 2.9, c: 3.6, g: 0.4 }, { n: 'Berenjena', en: 'Aubergine', k: 25, p: 1, c: 6, g: 0.2 },
      { n: 'Pimiento rojo', en: 'Red pepper', k: 26, p: 1, c: 6, g: 0.3 }, { n: 'Judías verdes', en: 'Green beans', k: 31, p: 1.8, c: 7, g: 0.1 },
      { n: 'Brócoli', en: 'Broccoli', k: 34, p: 2.8, c: 7, g: 0.4 }, { n: 'Cebolla', en: 'Onion', k: 40, p: 1.1, c: 9, g: 0.1 },
      { n: 'Zanahoria', en: 'Carrot', k: 41, p: 0.9, c: 10, g: 0.2 }
    ],
    salsa: [
      { n: 'Salsa de tomate', en: 'Tomato sauce', k: 29, p: 1.3, c: 6, g: 0.2 }, { n: 'Salsa barbacoa 0%', en: 'Barbecue sauce 0%', k: 30, p: 0.6, c: 6.5, g: 0.1 },
      { n: 'Kétchup', en: 'Ketchup', k: 112, p: 1.3, c: 26, g: 0.1 }, { n: 'Salsa 4 quesos', en: 'Four cheese sauce', k: 120, p: 3, c: 4, g: 10 },
      { n: 'Salsa carbonara', en: 'Carbonara sauce', k: 128, p: 2.8, c: 4.4, g: 11 }, { n: 'Salsa roquefort', en: 'Roquefort sauce', k: 180, p: 4, c: 5, g: 16 },
      { n: 'Salsa de pesto', en: 'Pesto sauce', k: 300, p: 5, c: 3, g: 30 }, { n: 'Mayonesa', en: 'Mayonnaise', k: 680, p: 1, c: 0.6, g: 75 }
    ]
  };
  var KW = {
    verdura: ['tomate', 'tomato', 'brocoli', 'broccoli', 'zanahoria', 'carrot', 'pimiento', 'pepper', 'esparrago', 'asparagus', 'alcachofa', 'champiñ', 'champin', 'mushroom', 'pepino', 'cucumber', 'cebolla', 'onion', 'lechuga', 'lettuce', 'ensalada', 'salad', 'judia', 'green bean', 'calabacin', 'zucchini', 'espinaca', 'spinach', 'verdura', 'menestra', 'pure de verd'],
    fruta: ['platano', 'banana', 'fresa', 'strawberr', 'mango', 'papaya', 'manzana', 'apple', 'arandano', 'blueberr', 'frutos rojos', 'pera', 'pear', 'naranja', 'orange', 'kiwi', 'uva', 'grape', 'sandia', 'melon', 'piña', 'pina', 'pineapple', 'fruta'],
    salsa: ['ketchup', 'tomate frito', 'tomato sauce', 'salsa', 'carbonara', 'pesto', 'canela', 'cinnamon', 'mermelada', 'jelly', 'cacao', 'chocolate', 'choco', 'sirope', 'syrup', 'barra de', 'barrita', 'whey', 'proteina en polvo', 'granola', 'cereal', 'corn flakes', 'weetabix'],
    lacteo: ['leche', 'milk', 'yogur', 'yogurt', 'kefir', 'kéfir', 'batido'],
    prote: ['huevo', 'egg', 'clara', 'jamon', 'ham']
  };
  function nrm(s) { return String(s == null ? '' : s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim(); }
  // El nombre viene con marca ("Yogur Griego - Hacendado"): la marca se quita antes de clasificar,
  // si no, el alimento acaba en la familia equivocada según de dónde sea.
  function sinMarca(s) { return String(s == null ? '' : s).replace(/\s*-\s*[^-]+$/, '').trim(); }
  // Reglas de Alex (30 ago). El ORDEN importa: lo más específico primero.
  var REGLAS = [
    // Las aceitunas van antes: "Acei-tuna-s" contenía «tuna» y salían como proteína.
    [/aceituna|\bolives?\b/i, 'grasa'],
    // Las salsas van de las PRIMERAS a proposito. Si no, "Salsa 4 quesos" caia en lacteos por
    // la palabra «queso», y la mayonesa se colaba entre las grasas y se cambiaba por aceite.
    // Toda esta familia esta fija (Alex, 30 ago): las salsas no se cambian entre si.
    [/\bsalsas?\b|\bsauce\b|mayonesa|mayonnaise|\bmayo\b|alioli|aioli|mostaza|mustard|vinagreta|vinaigrette|k[e\u00e9]tchup|ketchup|barbacoa|barbecue|\bbbq\b|sriracha|teriyaki|t[a\u00e1]rtara|pesto|carbonara|boloñesa|bolognese/i, 'salsa'],
    [/burguer|burger|hamburguesa/i, 'prote'],
    // ojo con las palabras cortas: van con límite de palabra o pescan trozos de otras
    [/\bcarne|beef|pollo|chicken|pavo|turkey|cerdo|pork|ternera|salm[oó]n|\bat[uú]n\b|\btuna\b|merluza|hake|bacalao|\bcod\b|gambas|shrimp|prawns|huevo|\begg/i, 'prote'],
    [/\blomo\b|solomillo|\bfilete\b|bistec|steak|chuleta|costilla|ribs/i, 'prote'],
    [/whey|isolate|proteina en polvo|protein powder|impact/i, 'prote'],
    [/barrita de prote|protein bar/i, 'prote'],
    [/bebida de|leche de|\bmilk\b|\bleche\b|yogur|yoghurt|yogurt|kefir|batido|queso|cheese/i, 'lacteo'],
    [/granola|corn flakes|copos de|muesli|weetabix|tortitas? de arroz|tortas de arroz|rice cakes?|crema de arroz|cereal|gachas|porridge|avena|\boats?\b|oatmeal/i, 'carbo'],
    [/barra de pan|\bpan\b|\bbread\b|baguette|tostadas?|toast/i, 'carbo']
  ];
  function grupoDe(food) {
    var base = sinMarca(food.name);
    for (var r = 0; r < REGLAS.length; r++) { if (REGLAS[r][0].test(base)) return REGLAS[r][1]; }
    var n = nrm(base);
    for (var g in KW) { for (var i = 0; i < KW[g].length; i++) { if (n.indexOf(nrm(KW[g][i])) >= 0) return g; } }
    var kp = (food.p || 0) * 4, kc = (food.c || 0) * 4, kg = (food.g || 0) * 9, mx = Math.max(kp, kc, kg);
    if (mx <= 0) return null;
    if (mx === kg) return 'grasa'; if (mx === kp) return 'prote'; return 'carbo';
  }
  // Mismo alimento con otro nombre. "Macarrones" es pasta, y ofrecerle pasta al cliente que
  // ya tiene macarrones no es un cambio.
  var SINONIMOS = [
    ['pasta', 'macarrones', 'macaroni', 'espaguetis', 'espagueti', 'spaguetti', 'spaghetti', 'penne', 'fusilli', 'tallarines', 'noodles', 'fideos'],
    ['crema de cacahuete', 'peanut butter', 'mantequilla de cacahuete'],
    ['boniato', 'batata', 'sweet potato'],
    ['gambas', 'langostinos', 'shrimp', 'prawns'],
    ['avena', 'oats', 'oatmeal', 'porridge', 'gachas'],
    ['pechuga de pollo', 'chicken breast', 'pollo', 'chicken']
  ];
  // Nombres del MISMO alimento en los dos idiomas, para no ofrecerlo como su propia variante.
  function claves(nombre) {
    var base = sinMarca(nombre), out = [nrm(base)];
    try {
      var I = w.I18N;
      if (I && I.food) {
        var es = nrm(sinMarca(I.food(base, 'es'))); if (es && out.indexOf(es) < 0) out.push(es);
        var en = nrm(sinMarca(I.food(base, 'en'))); if (en && out.indexOf(en) < 0) out.push(en);
      }
    } catch (e) {}
    for (var i = 0; i < SINONIMOS.length; i++) {
      var gp = SINONIMOS[i];
      for (var j = 0; j < out.length; j++) {
        if (gp.indexOf(out[j]) >= 0) { if (out.indexOf(gp[0]) < 0) out.push(gp[0]); break; }
      }
    }
    return out.filter(Boolean);
  }
  // Sobran los adjetivos de coccion: "Garbanzos cocidos" y "Garbanzos" son el mismo garbanzo.
  // Solo el estado de coccion. OJO: "natural" y "fresco" NO se quitan, porque distinguen
  // alimentos de verdad (Yogur natural / Yogur griego, Atun al natural, Queso fresco).
  var RELLENO = /\b(cocid[oa]s?|cocinad[oa]s?|hervid[oa]s?|crud[oa]s?|cooked|boiled|raw)\b/g;
  function nucleo(k) { return k.replace(RELLENO, ' ').replace(/\s+/g, ' ').trim(); }
  function mismoAlimento(a, b) {
    for (var i = 0; i < a.length; i++) {
      var x = nucleo(a[i]); if (!x) continue;
      for (var j = 0; j < b.length; j++) {
        var y = nucleo(b[j]); if (!y) continue;
        if (x === y || x.indexOf(y) >= 0 || y.indexOf(x) >= 0) return true;
      }
    }
    return false;
  }
  // Alex (30 ago). Las SALSAS ya no se cambian entre si: entre un ketchup y una mayonesa hay
  // 29 y 680 kcal por 100 g, y aunque cuadren las calorias no son la misma cosa. Palabras suyas:
  // "al cliente no se le puede abrir tanto la puerta como para que al pasar se caiga".
  var SUST = { carbo: 1, prote: 1, grasa: 1, lacteo: 1, fruta: 1, verdura: 1 };
  // Alex (30 ago). El HUEVO ENTERO no se cambia por nada: 150 g son 222 kcal pero solo 19 g de
  // proteina (la mitad de sus calorias son grasa), asi que igualar calorias con cualquier carne
  // magra le duplica la proteina. Una tortilla es una tortilla. Las CLARAS si se cambian.
  var HUEVO_ENTERO = /huevo|\bhuevos\b|\begg\b|\beggs\b|tortilla|omelet|omelette|revuelto|scrambled/i;
  var ES_CLARA = /clara|\bclaras\b|egg\s*white|albumina/i;
  function huevoEntero(food) {
    var b = sinMarca(food && food.name);
    return HUEVO_ENTERO.test(b) && !ES_CLARA.test(b);
  }
  function esFijo(food) { var g = grupoDe(food); return !g || !SUST[g] || huevoEntero(food); }
  function r1(x) { return Math.round(x * 10) / 10; }
  function alternativas(food, lang) {
    var g = grupoDe(food);
    if (!g || !SUST[g]) return null;
    if (huevoEntero(food)) return null;   // tortilla, revuelto, huevo entero: no hay cambio
    // El plan de Alex escribe los alimentos en INGLES ("White Rice") y nuestra lista esta en
    // espanol ("Arroz blanco"). Si comparamos solo el texto no vemos que son el MISMO alimento
    // y acabamos ofreciendole al cliente "cambia tu arroz por arroz". Traducimos los dos lados.
    var self = claves(food.name);
    var k0 = (food.unit === 'g' && food.qty > 0) ? (food.kcal * 100 / food.qty) : 0;
    var list = ALT[g].filter(function (a) { return !mismoAlimento(self, claves(a.n).concat(claves(a.en))); });
    // Alex (30 ago): "las calorias son lo mas importante, pero la proteina tiene que ser
    // parecida, no un cambio brusco". Las calorias ya salen clavadas por construccion (se
    // calculan los gramos justos), asi que lo que ordena aqui es el PARECIDO DE MACROS:
    // que reparto de calorias entre proteina, hidratos y grasa tiene cada uno. Las cuatro
    // opciones que ve el cliente son las cuatro mas parecidas de su familia.
    var perf0 = perfil(food);
    list = list.slice().sort(function (a, b) { return distancia(perfil(a), perf0) - distancia(perfil(b), perf0); });
    // Alex: por debajo de 15 g no se ofrece. Nadie pesa 4 g de salsa, y un cambio así confunde.
    // Y por arriba tampoco: cambiar queso parmesano por 2,5 KILOS de leche cuadra en calorías
    // pero no es una comida. Tope: 400 g o 4 veces la ración original, lo que sea menor.
    var MIN_G = 15;
    var qty0 = (food.unit === 'g' && food.qty > 0) ? food.qty : 0;
    var MAX_G = qty0 > 0 ? Math.min(400, qty0 * 4) : 400;
    // Además el cambio tiene que parecerse en LO QUE APORTA, no solo en calorías: lo que manda
    // en el original (proteína, hidratos o grasa) tiene que mandar también en el sustituto.
    // Reparto de las calorias del alimento: cuanto viene de proteina, cuanto de hidratos y
    // cuanto de grasa. Sirve para comparar dos alimentos de tamanos distintos.
    function perfil(o) {
      var kp = (o.p || 0) * 4, kc = (o.c || 0) * 4, kg = (o.g || 0) * 9, t = kp + kc + kg;
      return t > 0 ? [kp / t, kc / t, kg / t] : null;
    }
    function distancia(a, b) {
      if (!a || !b) return 2;
      return Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]) + Math.abs(a[2] - b[2]);
    }
    function manda(o) {
      var kp = (o.p || 0) * 4, kc = (o.c || 0) * 4, kg = (o.g || 0) * 9, mx = Math.max(kp, kc, kg);
      if (mx <= 0) return '';
      return mx === kg ? 'g' : (mx === kp ? 'p' : 'c');
    }
    var m0 = manda(food);
    var enRango = function (a) {
      var gr = Math.round(food.kcal / (a.k / 100));
      return gr >= MIN_G && gr <= MAX_G;
    };
    var dentro = list.filter(enRango);
    // Preferimos que el sustituto aporte LO MISMO (proteina por proteina, grasa por grasa).
    // Pero la norma de Alex manda: "cualquier sustitucion siempre se iguala a nivel de calorias".
    // Asi que esto es una PREFERENCIA, no un muro: si al exigirlo nos quedamos sin opciones
    // (le pasaba al yogur griego y al ketchup, que se quedaban sin ni una), abrimos la familia
    // entera ordenada por calorias. El tope de gramos de arriba ya evita los cambios absurdos.
    var mismos = m0 ? dentro.filter(function (a) { return manda(a) === m0; }) : dentro;
    // Alex (30 ago): "no puede ser un cambio brusco, si no no va a dar el numero". Las calorias
    // salen clavadas siempre, pero el macro que MANDA en el alimento (la proteina en una carne,
    // los hidratos en un arroz) no puede irse mas de un 30%. Ejemplo de por que hace falta:
    // 150 g de huevo son 222 kcal pero solo 19 g de proteina, y al igualar calorias con pollo
    // salian 43 g. Mas del doble.
    var TOPE = 0.30;
    function dominante(o) { var m = manda(o); return m === 'p' ? (o.p || 0) : (m === 'c' ? (o.c || 0) : (o.g || 0)); }
    var base0 = dominante(food);
    function suave(a) {
      if (!base0 || !m0) return true;
      var gr = food.kcal / (a.k / 100);
      var val = (m0 === 'p' ? a.p : (m0 === 'c' ? a.c : a.g)) * gr / 100;
      return Math.abs(val - base0) / base0 <= TOPE;
    }
    var buenos = mismos.filter(suave);
    // Igual que con las salsas: esto es lo que se PREFIERE, no un muro. Si el tope deja al
    // cliente con menos de dos opciones, se abre la mano antes que dejarle sin ningun cambio.
    var finales = buenos.length >= 2 ? buenos
      : buenos.concat(mismos.filter(function (a) { return buenos.indexOf(a) < 0; }))
              .concat(dentro.filter(function (a) { return mismos.indexOf(a) < 0; }));
    return finales.map(function (a) {
      return { a: a, grams: Math.round(food.kcal / (a.k / 100)) };
    }).filter(function (x) { return x.grams >= MIN_G && x.grams <= MAX_G; }).slice(0, 4).map(function (o) {
      var a = o.a, grams = o.grams;
      return {
        name: (lang === 'en' ? a.en : a.n), grams: grams, grupo: g,
        kcal: Math.round(grams * a.k / 100),          // kcal reales del sustituto (≈ objetivo)
        p: r1(grams * a.p / 100), c: r1(grams * a.c / 100), g: r1(grams * a.g / 100) // macros por detrás
      };
    });
  }
  w.EQUIV = { grupoDe: grupoDe, esFijo: esFijo, alternativas: alternativas };
})(typeof window !== 'undefined' ? window : globalThis);
